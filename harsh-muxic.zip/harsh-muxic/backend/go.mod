module github.com/KabirSinghBhatia/BitChord/backend

go 1.27.0

require github.com/gorilla/websocket v1.5.3 // indirect
