package com.music.bitchord.ui.screens

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.music.bitchord.playback.LanSync

/** Host or join an offline (Wi-Fi / hotspot) listening party. See [LanSync]. */
@Composable
fun OfflinePartyDialog(onDismiss: () -> Unit) {
    val ui by LanSync.state.collectAsStateWithLifecycle()
    var ip by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Offline party (Wi-Fi)") },
        text = {
            Column {
                when (ui.role) {
                    LanSync.Role.NONE -> {
                        Text(
                            "Internet ki zaroorat nahi. Dono phone ek hi Wi-Fi par ho, ya ek phone ka hotspot on karke doosra usse jud jaye. " +
                                "Host par gaana pehle Download hona chahiye.",
                            style = MaterialTheme.typography.bodyMedium,
                        )
                        Spacer(Modifier.height(16.dp))
                        Button(onClick = { LanSync.startHost() }, enabled = ui.attached, modifier = Modifier.fillMaxWidth()) {
                            Text("Host banao (is phone se gaana chalega)")
                        }
                        Spacer(Modifier.height(16.dp))
                        OutlinedTextField(
                            value = ip,
                            onValueChange = { ip = it },
                            singleLine = true,
                            label = { Text("Host ka IP (jaise 192.168.1.5)") },
                            modifier = Modifier.fillMaxWidth(),
                        )
                        Spacer(Modifier.height(8.dp))
                        OutlinedButton(
                            onClick = { LanSync.join(ip) },
                            enabled = ui.attached && ip.isNotBlank(),
                            modifier = Modifier.fillMaxWidth(),
                        ) { Text("Join karo") }
                        if (!ui.attached) {
                            Spacer(Modifier.height(8.dp))
                            Text("Pehle koi gaana chalao, phir yaha aao.", style = MaterialTheme.typography.bodySmall)
                        }
                    }
                    LanSync.Role.HOST -> {
                        Text("Aap host ho. Doosre phone me ye IP daalo:", style = MaterialTheme.typography.bodyMedium)
                        Spacer(Modifier.height(8.dp))
                        Text(
                            if (ui.addresses.isEmpty()) "IP nahi mila. Wi-Fi ya hotspot on karo" else ui.addresses.joinToString("\n"),
                            style = MaterialTheme.typography.titleLarge,
                        )
                        Spacer(Modifier.height(8.dp))
                        Text("Judey hue phone: ${ui.guests}", style = MaterialTheme.typography.bodyMedium)
                        Text("Ab koi downloaded gaana chalao, dono me chalega.", style = MaterialTheme.typography.bodySmall)
                    }
                    LanSync.Role.GUEST -> {
                        Text("Aap guest ho. Gaana host ke saath chalega.", style = MaterialTheme.typography.bodyMedium)
                    }
                }
                if (ui.status.isNotBlank()) {
                    Spacer(Modifier.height(12.dp))
                    Text(ui.status, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary)
                }
            }
        },
        confirmButton = {
            if (ui.role != LanSync.Role.NONE) {
                TextButton(onClick = { LanSync.stop() }) { Text("Band karo") }
            } else {
                TextButton(onClick = onDismiss) { Text("Close") }
            }
        },
        dismissButton = {
            if (ui.role != LanSync.Role.NONE) TextButton(onClick = onDismiss) { Text("Chhupao") }
        },
    )
}
