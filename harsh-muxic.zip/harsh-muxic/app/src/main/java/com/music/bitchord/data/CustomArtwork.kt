package com.music.bitchord.data

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.compose.runtime.mutableStateMapOf
import java.io.File
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Cover images the person picked from their own gallery, one per song.
 *
 * The picked image is scaled down and copied into the app's private storage, so
 * it keeps working after the original is moved or deleted. The map is Compose
 * snapshot state: any composable that reads [forSong] while drawing a song's art
 * redraws on its own when a cover is set or reset.
 */
object CustomArtwork {

    private const val PREFS = "custom_artwork"
    private const val DIR = "custom_art"

    /** Longest side kept, in pixels. Enough for the 4K player setting. */
    private const val MAX_PX = 3840

    /** videoId -> `file://` URI of the picked image. */
    private val uris = mutableStateMapOf<String, String>()

    fun init(context: Context) {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        prefs.all.forEach { (videoId, value) ->
            val file = (value as? String)?.let { File(it) } ?: return@forEach
            if (file.exists()) uris[videoId] = Uri.fromFile(file).toString()
        }
    }

    /** The picked cover for this song, or null to use the one it came with. */
    fun forSong(videoId: String?): String? = videoId?.let { uris[it] }

    /** Reads [source], scales it down and stores it as this song's cover. */
    suspend fun set(context: Context, videoId: String, source: Uri): Boolean =
        withContext(Dispatchers.IO) {
            runCatching {
                val resolver = context.contentResolver
                val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                resolver.openInputStream(source)?.use { BitmapFactory.decodeStream(it, null, bounds) }
                val longest = maxOf(bounds.outWidth, bounds.outHeight)
                if (longest <= 0) return@runCatching false

                var sample = 1
                while (longest / (sample * 2) >= MAX_PX) sample *= 2
                val decoded = resolver.openInputStream(source)?.use {
                    BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = sample })
                } ?: return@runCatching false

                val big = maxOf(decoded.width, decoded.height)
                val bitmap = if (big > MAX_PX) {
                    val k = MAX_PX.toFloat() / big
                    Bitmap.createScaledBitmap(
                        decoded,
                        (decoded.width * k).toInt().coerceAtLeast(1),
                        (decoded.height * k).toInt().coerceAtLeast(1),
                        true,
                    )
                } else decoded

                val dir = File(context.filesDir, DIR).apply { mkdirs() }
                // A new name each time so image caches never serve the previous cover.
                val file = File(dir, "art_${videoId.hashCode().toUInt().toString(16)}_${System.currentTimeMillis()}.jpg")
                file.outputStream().use { bitmap.compress(Bitmap.CompressFormat.JPEG, 92, it) }

                val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                prefs.getString(videoId, null)?.let { File(it).delete() }
                prefs.edit().putString(videoId, file.absolutePath).apply()
                uris[videoId] = Uri.fromFile(file).toString()
                true
            }.getOrDefault(false)
        }

    /** Goes back to the cover the song came with. */
    fun clear(context: Context, videoId: String) {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        prefs.getString(videoId, null)?.let { File(it).delete() }
        prefs.edit().remove(videoId).apply()
        uris.remove(videoId)
    }
}
