package com.music.bitchord.playback

import android.os.SystemClock
import java.text.DateFormat
import java.util.Calendar
import kotlinx.coroutines.flow.MutableStateFlow

/**
 * Sleep timer. Holds a deadline; [PlaybackService] watches it and pauses
 * playback once it passes.
 *
 * A deadline rather than a countdown: nothing has to tick for the timer to
 * stay accurate, so it survives the player UI being dismissed, and any
 * observer can work out how long is left for itself. elapsedRealtime, not
 * wall clock, so changing the system time can't cut a timer short.
 */
object SleepTimer {

    /** Deadline on [SystemClock.elapsedRealtime], or null when no timer is set. */
    val deadline = MutableStateFlow<Long?>(null)

    /** The preset that was chosen, so the picker can tick it. Null when off. */
    val minutes = MutableStateFlow<Int?>(null)

    /**
     * Pause when the current track ends instead of after a fixed wait.
     *
     * Deliberately not expressed as a deadline of "duration minus position":
     * seeking, crossfade and a queue that reorders itself would all leave that
     * number wrong, whereas the track ending is an event the player reports.
     */
    val afterTrack = MutableStateFlow(false)

    /** The clock time the timer was set for ("11:30 PM"), or null when it was set as a duration. */
    val atLabel = MutableStateFlow<String?>(null)

    /** Durations offered in the picker. */
    val PRESETS = listOf(15, 30, 45, 60)

    /** Whether any kind of timer is currently armed. */
    val isRunning: Boolean get() = deadline.value != null || afterTrack.value

    fun start(minutes: Int) {
        afterTrack.value = false
        atLabel.value = null
        this.minutes.value = minutes
        deadline.value = SystemClock.elapsedRealtime() + minutes * 60_000L
    }

    /**
     * Pause when the wall clock next reaches [hour]:[minute] — today if that is still
     * ahead, otherwise tomorrow. Turned into a duration once, here, so the rest of the
     * timer keeps working off the monotonic clock.
     */
    fun startAtClock(hour: Int, minute: Int) {
        val now = Calendar.getInstance()
        val target = (now.clone() as Calendar).apply {
            set(Calendar.HOUR_OF_DAY, hour)
            set(Calendar.MINUTE, minute)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        if (!target.after(now)) target.add(Calendar.DAY_OF_YEAR, 1)
        afterTrack.value = false
        minutes.value = null
        atLabel.value = DateFormat.getTimeInstance(DateFormat.SHORT).format(target.time)
        deadline.value = SystemClock.elapsedRealtime() + (target.timeInMillis - now.timeInMillis)
    }

    /** Pause once the track playing right now finishes. */
    fun startAfterTrack() {
        atLabel.value = null
        minutes.value = null
        deadline.value = null
        afterTrack.value = true
    }

    fun cancel() {
        atLabel.value = null
        minutes.value = null
        deadline.value = null
        afterTrack.value = false
    }

    /** How long is left, or null when no timer is running. */
    fun remainingMs(): Long? =
        deadline.value?.let { (it - SystemClock.elapsedRealtime()).coerceAtLeast(0L) }
}
