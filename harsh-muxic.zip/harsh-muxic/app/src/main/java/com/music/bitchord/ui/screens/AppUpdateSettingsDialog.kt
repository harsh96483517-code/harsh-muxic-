package com.music.bitchord.ui.screens

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.music.bitchord.BuildConfig
import com.music.bitchord.data.AppUpdateChecker
import kotlinx.coroutines.launch

/** "Check for updates" from Settings: checks, then downloads and installs in place. */
@Composable
fun AppUpdateSettingsDialog(onDismiss: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    // 2 = checking, 1 = available, 0 = up to date, -1 = failed
    var result by remember { mutableIntStateOf(2) }
    val available by AppUpdateChecker.available.collectAsStateWithLifecycle()
    val download by AppUpdateChecker.download.collectAsStateWithLifecycle()
    LaunchedEffect(Unit) { result = AppUpdateChecker.checkNow() }
    val update = available
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                when {
                    result == 2 -> "Update check ho raha hai..."
                    update != null && result == 1 -> "Naya update ${update.version}"
                    result == 0 -> "App up to date hai"
                    else -> "Update check nahi ho paya"
                },
            )
        },
        text = {
            Column {
                Text("Abhi ka version: ${BuildConfig.VERSION_NAME}", style = MaterialTheme.typography.bodyMedium)
                if (result == -1) {
                    Spacer(Modifier.height(8.dp))
                    Text("Internet check karo, aur GitHub repo Public hona chahiye. Release bani honi chahiye.", style = MaterialTheme.typography.bodySmall)
                }
                if (update != null && result == 1) {
                    Spacer(Modifier.height(8.dp))
                    update.notes?.takeIf { it.isNotBlank() }?.let {
                        Text(it.take(500), style = MaterialTheme.typography.bodySmall)
                    }
                    when (val d = download) {
                        is AppUpdateChecker.DownloadState.Downloading -> {
                            Spacer(Modifier.height(12.dp))
                            LinearProgressIndicator(progress = { d.fraction }, modifier = Modifier.fillMaxWidth())
                            Text("Download ho raha hai ${(d.fraction * 100).toInt()}%", style = MaterialTheme.typography.bodySmall)
                        }
                        is AppUpdateChecker.DownloadState.Failed -> {
                            Spacer(Modifier.height(8.dp))
                            Text("Download fail: ${d.message}", style = MaterialTheme.typography.bodySmall)
                        }
                        else -> Unit
                    }
                }
            }
        },
        confirmButton = {
            val d = download
            if (update != null && result == 1) {
                when (d) {
                    is AppUpdateChecker.DownloadState.Ready ->
                        TextButton(onClick = { AppUpdateChecker.installApk(context, d.file) }) { Text("Install karo") }
                    is AppUpdateChecker.DownloadState.Downloading ->
                        TextButton(onClick = { AppUpdateChecker.cancelDownload() }) { Text("Cancel") }
                    else -> TextButton(onClick = {
                        if (update.apkUrl != null) scope.launch { AppUpdateChecker.downloadApk(context) }
                    }) { Text("Update karo") }
                }
            } else {
                TextButton(onClick = onDismiss) { Text("Theek hai") }
            }
        },
        dismissButton = {
            if (update != null && result == 1) TextButton(onClick = onDismiss) { Text("Baad me") }
        },
    )
}
