package com.music.bitchord.playback

import android.content.Context
import android.net.Uri
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.File
import java.net.InetSocketAddress
import java.net.NetworkInterface
import java.net.ServerSocket
import java.net.Socket
import java.security.MessageDigest
import java.util.concurrent.CopyOnWriteArrayList
import kotlin.concurrent.thread
import kotlin.math.abs

/**
 * Offline "listen together" over Wi-Fi: no internet and no server.
 *
 * One phone hosts (it opens a TCP port); the others type its IP address and
 * join. The same Wi-Fi works, and so does the host's own hotspot, which needs no
 * internet at all. The host streams its *downloaded* current song to a guest
 * the first time (the file goes over the socket), then only tiny state messages
 * (song, playing, position) keep every phone on the same second.
 *
 * Guests write to the ExoPlayer directly, below the session wrapper, the same
 * way [PartySync] does, so nothing a guest does here is read back as the
 * user's own action.
 */
object LanSync {
    enum class Role { NONE, HOST, GUEST }

    data class UiState(
        val attached: Boolean = false,
        val role: Role = Role.NONE,
        val status: String = "",
        val addresses: List<String> = emptyList(),
        val guests: Int = 0,
    )

    private data class StateMsg(
        val id: String,
        val title: String,
        val artist: String,
        val playing: Boolean,
        val pos: Long,
        val wall: Long,
        val local: Boolean,
    )

    private class Conn(val socket: Socket, val out: DataOutputStream) {
        @Synchronized
        fun send(block: DataOutputStream.() -> Unit) {
            out.block()
            out.flush()
        }
    }

    const val PORT = 8765
    private const val T_STATE = 2
    private const val T_NEED = 3
    private const val T_FILE = 4
    private const val T_PING = 5
    private const val T_PONG = 6

    private val _state = MutableStateFlow(UiState())
    val state: StateFlow<UiState> = _state.asStateFlow()

    private var appContext: Context? = null
    private var scope: CoroutineScope? = null
    private var playerProvider: (() -> Player?)? = null

    private var server: ServerSocket? = null
    private val guests = CopyOnWriteArrayList<Conn>()
    private var heartbeat: Job? = null

    private var client: Conn? = null
    @Volatile private var clockOffset = 0L
    @Volatile private var bestRtt = Long.MAX_VALUE
    @Volatile private var latest: StateMsg? = null
    private val requested = HashSet<String>()

    fun attach(context: Context, scope: CoroutineScope, player: () -> Player?) {
        appContext = context.applicationContext
        this.scope = scope
        playerProvider = player
        _state.update { it.copy(attached = true) }
    }

    fun detach() {
        stop()
        scope = null
        playerProvider = null
        _state.update { it.copy(attached = false) }
    }

    private fun status(text: String) = _state.update { it.copy(status = text) }

    // ---------------------------------------------------------------- host

    fun startHost() {
        val sc = scope ?: run {
            status("Pehle koi gaana chalao, phir dobara try karo")
            return
        }
        stop()
        val ss = try {
            ServerSocket().apply {
                reuseAddress = true
                bind(InetSocketAddress(PORT))
            }
        } catch (e: Exception) {
            status("Host nahi ban paya: ${e.message}")
            return
        }
        server = ss
        _state.update { it.copy(role = Role.HOST, addresses = localAddresses(), guests = 0, status = "Doosre phone me ye IP daalo") }
        thread(isDaemon = true, name = "lan-accept") {
            while (!ss.isClosed) {
                val s = try { ss.accept() } catch (e: Exception) { break }
                thread(isDaemon = true, name = "lan-guest") { serveGuest(s) }
            }
        }
        heartbeat = sc.launch { hostLoop() }
    }

    private suspend fun snapshot(): StateMsg? = withContext(Dispatchers.Main) {
        val p = playerProvider?.invoke() ?: return@withContext null
        val item = p.currentMediaItem ?: return@withContext null
        val scheme = item.localConfiguration?.uri?.scheme
        StateMsg(
            id = item.mediaId,
            title = item.mediaMetadata.title?.toString().orEmpty(),
            artist = item.mediaMetadata.artist?.toString().orEmpty(),
            playing = p.playWhenReady && p.playbackState != Player.STATE_ENDED && p.playbackState != Player.STATE_IDLE,
            pos = p.currentPosition,
            wall = System.currentTimeMillis(),
            local = scheme == "file" || scheme == "content",
        )
    }

    private suspend fun hostLoop() {
        var last: StateMsg? = null
        while (currentCoroutineContext().isActive) {
            val snap = snapshot()
            if (snap != null && guests.isNotEmpty()) {
                val prev = last
                val predicted = if (prev != null && prev.playing) prev.pos + (snap.wall - prev.wall) else prev?.pos ?: 0L
                val changed = prev == null || prev.id != snap.id || prev.playing != snap.playing ||
                    abs(predicted - snap.pos) > 1200 || snap.wall - prev.wall > 2000
                if (changed) {
                    last = snap
                    broadcast(snap)
                }
            }
            delay(400)
        }
    }

    private suspend fun broadcast(msg: StateMsg) = withContext(Dispatchers.IO) {
        for (g in guests) {
            try { g.send { writeState(msg) } } catch (e: Exception) { dropGuest(g) }
        }
    }

    private fun DataOutputStream.writeState(m: StateMsg) {
        writeInt(T_STATE)
        writeUTF(m.id); writeUTF(m.title); writeUTF(m.artist)
        writeBoolean(m.playing); writeLong(m.pos); writeLong(m.wall); writeBoolean(m.local)
    }

    private fun dropGuest(g: Conn) {
        guests.remove(g)
        runCatching { g.socket.close() }
        _state.update { it.copy(guests = guests.size) }
    }

    private fun serveGuest(s: Socket) {
        val input = DataInputStream(s.getInputStream().buffered())
        val conn = Conn(s, DataOutputStream(s.getOutputStream().buffered()))
        guests.add(conn)
        _state.update { it.copy(guests = guests.size, status = "${guests.size} phone juda hai") }
        scope?.launch {
            // Say hello with the current song right away rather than at the next beat.
            snapshot()?.let { broadcast(it) }
        }
        try {
            while (true) {
                when (input.readInt()) {
                    T_NEED -> sendFile(conn, input.readUTF())
                    T_PING -> {
                        val t = input.readLong()
                        conn.send { writeInt(T_PONG); writeLong(t); writeLong(System.currentTimeMillis()) }
                    }
                }
            }
        } catch (e: Exception) {
            // guest left
        } finally {
            dropGuest(conn)
        }
    }

    private fun sendFile(conn: Conn, id: String) {
        val ctx = appContext ?: return
        val sc = scope ?: return
        // The host's player knows where the song's file is.
        val uri: Uri? = kotlinx.coroutines.runBlocking {
            withContext(Dispatchers.Main) {
                val p = playerProvider?.invoke()
                val item = (0 until (p?.mediaItemCount ?: 0)).map { p!!.getMediaItemAt(it) }
                    .firstOrNull { it.mediaId == id }
                item?.localConfiguration?.uri?.takeIf { it.scheme == "file" || it.scheme == "content" }
            }
        }
        if (uri == null) return
        val tmp = File(ctx.cacheDir, "lan_send_${hash(id)}")
        try {
            ctx.contentResolver.openInputStream(uri)?.use { ins -> tmp.outputStream().use { ins.copyTo(it) } } ?: return
            conn.send {
                writeInt(T_FILE)
                writeUTF(id)
                writeLong(tmp.length())
                tmp.inputStream().use { it.copyTo(this) }
            }
        } finally {
            tmp.delete()
        }
        sc.launch { snapshot()?.let { broadcast(it) } }
    }

    private fun localAddresses(): List<String> = runCatching {
        NetworkInterface.getNetworkInterfaces().toList()
            .filter { it.isUp && !it.isLoopback }
            .flatMap { ni -> ni.inetAddresses.toList().filter { !it.isLoopbackAddress && it.address.size == 4 }.map { it.hostAddress.orEmpty() } }
    }.getOrDefault(emptyList())

    // --------------------------------------------------------------- guest

    fun join(host: String) {
        if (scope == null) {
            status("Pehle koi gaana chalao, phir dobara try karo")
            return
        }
        stop()
        _state.update { it.copy(role = Role.GUEST, status = "Judne ki koshish...") }
        thread(isDaemon = true, name = "lan-client") {
            try {
                val s = Socket()
                s.connect(InetSocketAddress(host.trim(), PORT), 6000)
                val conn = Conn(s, DataOutputStream(s.getOutputStream().buffered()))
                client = conn
                bestRtt = Long.MAX_VALUE
                status("Juda hua. Host gaana chalayega to yaha bhi chalega")
                thread(isDaemon = true, name = "lan-ping") {
                    var n = 0
                    try {
                        while (!s.isClosed) {
                            conn.send { writeInt(T_PING); writeLong(System.currentTimeMillis()) }
                            Thread.sleep(if (n++ < 10) 700 else 5000)
                        }
                    } catch (e: Exception) { }
                }
                val input = DataInputStream(s.getInputStream().buffered())
                while (true) {
                    when (input.readInt()) {
                        T_STATE -> onState(
                            StateMsg(
                                input.readUTF(), input.readUTF(), input.readUTF(),
                                input.readBoolean(), input.readLong(), input.readLong(), input.readBoolean(),
                            ),
                        )
                        T_FILE -> receiveFile(input)
                        T_PONG -> {
                            val sent = input.readLong()
                            val hostNow = input.readLong()
                            val now = System.currentTimeMillis()
                            val rtt = now - sent
                            if (rtt < bestRtt) bestRtt = rtt
                            if (rtt <= bestRtt + 20) clockOffset = hostNow + rtt / 2 - now
                        }
                    }
                }
            } catch (e: Exception) {
                if (_state.value.role == Role.GUEST) status("Connection toot gaya: ${e.message ?: "host nahi mila"}")
            }
        }
    }

    private fun lanFile(id: String): File {
        val dir = File(appContext!!.cacheDir, "lan").apply { mkdirs() }
        return File(dir, hash(id))
    }

    private fun hash(id: String): String =
        MessageDigest.getInstance("SHA-1").digest(id.toByteArray()).joinToString("") { "%02x".format(it) }

    private fun receiveFile(input: DataInputStream) {
        val id = input.readUTF()
        val len = input.readLong()
        val target = lanFile(id)
        val tmp = File(target.parentFile, target.name + ".part")
        tmp.outputStream().use { out ->
            var left = len
            val buf = ByteArray(64 * 1024)
            while (left > 0) {
                val n = input.read(buf, 0, minOf(buf.size.toLong(), left).toInt())
                if (n < 0) throw java.io.EOFException()
                out.write(buf, 0, n)
                left -= n
            }
        }
        tmp.renameTo(target)
        latest?.takeIf { it.id == id }?.let { apply(it) }
    }

    private fun onState(msg: StateMsg) {
        latest = msg
        if (!msg.local) {
            status("Host ka gaana online hai. Host par pehle use Download karo")
            return
        }
        val f = lanFile(msg.id)
        if (!f.exists()) {
            if (requested.add(msg.id)) {
                status("Gaana aa raha hai: ${msg.title}")
                runCatching { client?.send { writeInt(T_NEED); writeUTF(msg.id) } }
            }
            return
        }
        apply(msg)
    }

    private fun apply(msg: StateMsg) {
        val sc = scope ?: return
        sc.launch(Dispatchers.Main) {
            val p = playerProvider?.invoke() ?: return@launch
            val target = (if (msg.playing) msg.pos + (System.currentTimeMillis() + clockOffset - msg.wall) else msg.pos).coerceAtLeast(0L)
            val wanted = "lan:${msg.id}"
            if (p.currentMediaItem?.mediaId != wanted) {
                val item = MediaItem.Builder()
                    .setMediaId(wanted)
                    .setUri(Uri.fromFile(lanFile(msg.id)))
                    .setMediaMetadata(MediaMetadata.Builder().setTitle(msg.title).setArtist(msg.artist).build())
                    .build()
                p.setMediaItem(item)
                p.prepare()
                p.seekTo(target)
            } else if (abs(p.currentPosition - target) > 450) {
                p.seekTo(target)
            }
            p.playWhenReady = msg.playing
            status("Sync chal raha hai: ${msg.title}")
        }
    }

    // ---------------------------------------------------------------- stop

    fun stop() {
        heartbeat?.cancel(); heartbeat = null
        runCatching { server?.close() }; server = null
        for (g in guests) runCatching { g.socket.close() }
        guests.clear()
        runCatching { client?.socket?.close() }; client = null
        requested.clear()
        latest = null
        appContext?.let { runCatching { File(it.cacheDir, "lan").deleteRecursively() } }
        _state.update { it.copy(role = Role.NONE, status = "", addresses = emptyList(), guests = 0) }
    }
}
