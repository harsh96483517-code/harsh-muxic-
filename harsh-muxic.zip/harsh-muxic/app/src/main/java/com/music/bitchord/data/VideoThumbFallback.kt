package com.music.bitchord.data

import coil3.intercept.Interceptor
import coil3.request.ErrorResult
import coil3.request.ImageResult

/**
 * Steps a YouTube video thumbnail down to a smaller size when the largest one
 * does not exist.
 *
 * `maxresdefault.jpg` is only generated for videos uploaded in HD, and the server
 * answers a missing one with a 404. Rather than know in advance which videos have
 * it, the big surfaces always ask for it and this retries the next best size.
 */
class VideoThumbFallback : Interceptor {
    override suspend fun intercept(chain: Interceptor.Chain): ImageResult {
        val result = chain.proceed()
        val url = chain.request.data as? String ?: return result
        if (result !is ErrorResult || !url.contains("/maxresdefault.")) return result
        for (name in FALLBACKS) {
            val retry = chain.request.newBuilder().data(url.replace("maxresdefault", name)).build()
            val next = chain.withRequest(retry).proceed()
            if (next !is ErrorResult) return next
        }
        return result
    }

    private companion object {
        val FALLBACKS = listOf("hq720", "sddefault", "hqdefault")
    }
}
