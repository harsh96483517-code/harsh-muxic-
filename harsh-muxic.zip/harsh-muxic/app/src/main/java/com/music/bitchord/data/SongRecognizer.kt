package com.music.bitchord.data

import android.annotation.SuppressLint
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.UUID

/**
 * Listens through the microphone for a few seconds and asks AudD.io which song
 * is playing — the "what is this song" button. Needs RECORD_AUDIO and an AudD
 * API token (Settings-free: the search bar asks for it the first time).
 */
object SongRecognizer {
    data class Match(val title: String, val artist: String)

    sealed interface Outcome {
        data class Found(val match: Match) : Outcome
        data object NotFound : Outcome
        data class Failed(val message: String) : Outcome
    }

    private const val SAMPLE_RATE = 16000
    private const val LISTEN_SECONDS = 8

    @SuppressLint("MissingPermission")
    suspend fun listenAndIdentify(token: String): Outcome = withContext(Dispatchers.IO) {
        val pcm = try {
            record()
        } catch (e: Exception) {
            return@withContext Outcome.Failed("Could not use the microphone")
        } ?: return@withContext Outcome.Failed("Could not use the microphone")
        try {
            val wav = toWav(pcm)
            val json = upload(token, wav)
            parse(json)
        } catch (e: Exception) {
            Outcome.Failed("Check your internet and try again")
        }
    }

    @SuppressLint("MissingPermission")
    private fun record(): ByteArray? {
        val minBuf = AudioRecord.getMinBufferSize(
            SAMPLE_RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT,
        )
        if (minBuf <= 0) return null
        val rec = AudioRecord(
            MediaRecorder.AudioSource.MIC, SAMPLE_RATE,
            AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, minBuf * 2,
        )
        if (rec.state != AudioRecord.STATE_INITIALIZED) {
            rec.release(); return null
        }
        val out = ByteArrayOutputStream()
        val buf = ByteArray(minBuf)
        val total = SAMPLE_RATE * 2 * LISTEN_SECONDS
        rec.startRecording()
        try {
            while (out.size() < total) {
                val n = rec.read(buf, 0, buf.size)
                if (n <= 0) break
                out.write(buf, 0, n)
            }
        } finally {
            runCatching { rec.stop() }
            rec.release()
        }
        return out.toByteArray()
    }

    private fun toWav(pcm: ByteArray): ByteArray {
        val out = ByteArrayOutputStream()
        fun le32(v: Int) { out.write(v and 255); out.write((v shr 8) and 255); out.write((v shr 16) and 255); out.write((v shr 24) and 255) }
        fun le16(v: Int) { out.write(v and 255); out.write((v shr 8) and 255) }
        out.write("RIFF".toByteArray()); le32(36 + pcm.size)
        out.write("WAVEfmt ".toByteArray()); le32(16); le16(1); le16(1)
        le32(SAMPLE_RATE); le32(SAMPLE_RATE * 2); le16(2); le16(16)
        out.write("data".toByteArray()); le32(pcm.size)
        out.write(pcm)
        return out.toByteArray()
    }

    private fun upload(token: String, wav: ByteArray): String {
        val boundary = "----harsh" + UUID.randomUUID().toString().replace("-", "")
        val conn = URL("https://api.audd.io/").openConnection() as HttpURLConnection
        conn.requestMethod = "POST"
        conn.doOutput = true
        conn.connectTimeout = 15000
        conn.readTimeout = 30000
        conn.setRequestProperty("Content-Type", "multipart/form-data; boundary=$boundary")
        conn.outputStream.use { os ->
            fun field(name: String, value: String) {
                os.write("--$boundary\r\nContent-Disposition: form-data; name=\"$name\"\r\n\r\n$value\r\n".toByteArray())
            }
            field("api_token", token)
            os.write(
                ("--$boundary\r\nContent-Disposition: form-data; name=\"file\"; filename=\"clip.wav\"\r\n" +
                    "Content-Type: audio/wav\r\n\r\n").toByteArray(),
            )
            os.write(wav)
            os.write("\r\n--$boundary--\r\n".toByteArray())
        }
        val stream = if (conn.responseCode in 200..299) conn.inputStream else conn.errorStream
        return stream.bufferedReader().use { it.readText() }
    }

    private fun parse(body: String): Outcome {
        val root = JSONObject(body)
        if (root.optString("status") == "error") {
            val msg = root.optJSONObject("error")?.optString("error_message").orEmpty()
            return Outcome.Failed(msg.ifBlank { "Recognition service error (check the API token)" })
        }
        val result = root.optJSONObject("result") ?: return Outcome.NotFound
        val title = result.optString("title")
        val artist = result.optString("artist")
        if (title.isBlank()) return Outcome.NotFound
        return Outcome.Found(Match(title, artist))
    }
}
