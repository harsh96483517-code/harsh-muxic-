<div align="center">

<img src="Logo.png" alt="Harsh muxic app icon" width="200" />

# Harsh muxic

### Aesthetic YouTube Music Client

</div>

> [!IMPORTANT]
> Harsh muxic is not affiliated with, endorsed by, or connected to YouTube or Google in any way. Use it at your own discretion.

> [!NOTE]
> Harsh muxic is a modified fork of [BitChord](https://github.com/kushagrasinghx/BitChord) by [kushagrasinghx](https://github.com/kushagrasinghx), used under the GNU GPL v3.0. Changes from the original: app renamed to "Harsh muxic", new application ID (`com.harsh.muxic`), new app icon and branding. All credit for the original work goes to its author.

---

<div align="center">

<img src="Banner.png" alt="Harsh muxic banner" width="100%" />

</div>

## Features

**Playback**
- Search, browse and play anything available on YouTube Music.
- Hi-Res lossless audio — FLAC/ALAC from a configured module source, with YouTube Music as fallback.
- Gapless playback with true crossfade, adjustable 0–12s.
- Automix [Beta] — DJ-style transitions with beat-matching and tempo-stretching.
- Offline downloads with embedded metadata.
- Local music library integration.
- Background playback via a proper foreground media session.
- Apple-like lyrics animation — credit to [binimum](https://github.com/binimum/am-lyrics).

**Experience**
- Animated album canvas on the now-playing screen.
- Word-synced lyrics from multiple sources.
- Dynamic, artwork-driven Material theming.
- Frosted-glass UI via Haze.

**Connectivity & Accounts**
- Sign in with your Google account for personalized content.
- Discord Rich Presence.
- Scrobbling to Last.fm and ListenBrainz.
- Pluggable sources — add, edit, test and health-check module sources.

**Controls & Tweaks**
- Per-network audio quality (Wi-Fi vs mobile data).
- Playback speed (0.5×–2.0×) and skip silence.
- Sleep timer and system equalizer integration.
- Stats for nerds on the now-playing screen.

---

## Build

```bash
./gradlew assembleDevDebug
```

Copy `keystore.properties.example` to `keystore.properties` and fill it in to build a signed release.

---

## Disclaimer & Legal Notice

Harsh muxic is an independent third-party audio player and client. It is **not** associated with Google LLC, YouTube Music, Deezer, Telegram, or any of their parent companies.

- **No media hosting:** it does not host, upload, or store copyrighted music files. It only scans local device storage or streams media from public or user-authenticated APIs.
- **Fair use & API usage:** created for personal research, educational, and fair-use purposes. You are responsible for following your local copyright laws and the YouTube Terms of Service.
- **Copyleft:** free software under the GPLv3. Any distribution must come with the Corresponding Source under the same license.

---

## License

Licensed under the **GNU General Public License v3.0 (GPLv3)**. See [LICENSE](LICENSE). Original copyright remains with the BitChord author; modifications are also released under GPLv3.
