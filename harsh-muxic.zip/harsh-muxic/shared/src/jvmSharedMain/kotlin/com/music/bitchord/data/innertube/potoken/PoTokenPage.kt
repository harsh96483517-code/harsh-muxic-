package com.music.bitchord.data.innertube.potoken

/**
 * The page a PoToken browser loads: the BgUtils-style BotGuard client whose
 * `runBotGuard`, `createPoTokenMinter` and `obtainPoToken` the minter drives.
 * One copy for the phone's WebView and the desktop's JavaFX WebView alike.
 */
const val PO_TOKEN_HTML = """<!DOCTYPE html>
<html lang="en"><head><title></title><script>
    /**
     * BotGuard client for generating poTokens.
     * Updated to fix JavaScript 'this' binding issues and match BgUtils v3.2.0 patterns.
     */

    // Global state for BotGuard
    var bgVmFunctions = null;
    var bgVm = null;
    var bgProgram = null;
    var poTokenMinter = null;  // Minter callback - created ONCE during init, reused for all tokens

    function loadBotGuard(challengeData) {
      bgVm = window[challengeData.globalName];
      bgProgram = challengeData.program;
      bgVmFunctions = null;

      if (!bgVm)
        throw new Error('[BotGuardClient]: VM not found in the global object');

      if (!bgVm.a)
        throw new Error('[BotGuardClient]: Could not load program');

      // Use explicit variable capture instead of 'this' to avoid binding issues
      var vmFunctionsCallback = function (
        asyncSnapshotFunction,
        shutdownFunction,
        passEventFunction,
        checkCameraFunction
      ) {
        bgVmFunctions = {
          asyncSnapshotFunction: asyncSnapshotFunction,
          shutdownFunction: shutdownFunction,
          passEventFunction: passEventFunction,
          checkCameraFunction: checkCameraFunction
        };
      };

      // Execute the BotGuard program
      try {
        bgVm.a(bgProgram, vmFunctionsCallback, true, undefined, function () {/** no-op */ }, [ [], [] ]);
      } catch (e) {
        throw new Error('[BotGuardClient]: Failed to execute program: ' + e.message);
      }

      // Wait for vmFunctions to be populated (async callback)
      return new Promise(function (resolve, reject) {
        var attempts = 0;
        var maxAttempts = 10000; // 10 seconds at 1ms intervals
        var checkInterval = setInterval(function () {
          if (bgVmFunctions && bgVmFunctions.asyncSnapshotFunction) {
            clearInterval(checkInterval);
            resolve({
              vmFunctions: bgVmFunctions,
              vm: bgVm,
              program: bgProgram
            });
          } else if (attempts >= maxAttempts) {
            clearInterval(checkInterval);
            reject(new Error('[BotGuardClient]: Timeout waiting for asyncSnapshotFunction'));
          }
          attempts++;
        }, 1);
      });
    }

    /**
     * Takes a snapshot asynchronously using the loaded BotGuard.
     */
    function snapshot(botguard, args) {
      return new Promise(function (resolve, reject) {
        if (!botguard.vmFunctions || !botguard.vmFunctions.asyncSnapshotFunction) {
          return reject(new Error('[BotGuardClient]: Async snapshot function not found'));
        }

        try {
          botguard.vmFunctions.asyncSnapshotFunction(
            function (response) { resolve(response); },
            [
              args.contentBinding,
              args.signedTimestamp,
              args.webPoSignalOutput,
              args.skipPrivacyBuffer
            ]
          );
        } catch (e) {
          reject(new Error('[BotGuardClient]: Snapshot failed: ' + e.message));
        }
      });
    }

    function runBotGuard(challengeData) {
      var interpreterJavascript = challengeData.interpreterJavascript.privateDoNotAccessOrElseSafeScriptWrappedValue;

      if (interpreterJavascript) {
        new Function(interpreterJavascript)();
      } else {
        throw new Error('[BotGuardClient]: Could not load VM - no interpreter JavaScript');
      }

      var webPoSignalOutput = [];

      return loadBotGuard({
        globalName: challengeData.globalName,
        program: challengeData.program
      }).then(function (botguard) {
        return snapshot(botguard, { webPoSignalOutput: webPoSignalOutput });
      }).then(function (botguardResponse) {
        return { webPoSignalOutput: webPoSignalOutput, botguardResponse: botguardResponse };
      });
    }

    /**
     * Creates the poToken minter callback. MUST be called exactly ONCE during initialization,
     * right after runBotGuard completes. The minter is stored globally and reused for all tokens.
     * NOTE: getMinter() may return a Promise, so this function is async.
     * @param webPoSignalOutput - Array from BotGuard containing the minter factory function
     * @param integrityToken - The integrity token (as bytes/Uint8Array)
     * @returns Promise that resolves when minter is ready
     */
    async function createPoTokenMinter(webPoSignalOutput, integrityToken) {
      console.log('[createPoTokenMinter] ENTER - webPoSignalOutput type: ' + typeof webPoSignalOutput + ', length: ' + (webPoSignalOutput ? webPoSignalOutput.length : 'null'));
      console.log('[createPoTokenMinter] integrityToken type: ' + typeof integrityToken + ', is array: ' + Array.isArray(integrityToken));

      // Get the minter factory function from webPoSignalOutput
      var getMinter = webPoSignalOutput[0];
      console.log('[createPoTokenMinter] getMinter type: ' + typeof getMinter);

      if (!getMinter) {
        throw new Error('PMD:Undefined - webPoSignalOutput[0] is not defined');
      }

      if (typeof getMinter !== 'function') {
        throw new Error('PMD:NotFunction - webPoSignalOutput[0] is not a function, got: ' + typeof getMinter);
      }

      // Create the mint callback by passing the integrity token - THIS MUST ONLY HAPPEN ONCE!
      // NOTE: getMinter() may return a Promise, so we await it
      console.log('[createPoTokenMinter] Calling getMinter(integrityToken)...');
      var mintCallback;
      try {
        var minterResult = getMinter(integrityToken);
        console.log('[createPoTokenMinter] getMinter returned type: ' + typeof minterResult + ', isPromise: ' + (minterResult && typeof minterResult.then === 'function'));
        // Handle both sync and async getMinter
        if (minterResult && typeof minterResult.then === 'function') {
          console.log('[createPoTokenMinter] getMinter returned a Promise, awaiting...');
          mintCallback = await minterResult;
          console.log('[createPoTokenMinter] Promise resolved, mintCallback type: ' + typeof mintCallback);
        } else {
          mintCallback = minterResult;
        }
      } catch (e) {
        console.log('[createPoTokenMinter] getMinter EXCEPTION: ' + e.message);
        throw new Error('GMC:Failed - getMinter() threw: ' + e.message);
      }

      if (!mintCallback) {
        throw new Error('APF:Undefined - mintCallback is undefined');
      }

      if (typeof mintCallback !== 'function') {
        throw new Error('APF:NotFunction - mintCallback is not a function, got: ' + typeof mintCallback);
      }

      // Store the minter globally for reuse
      poTokenMinter = mintCallback;
      console.log('[createPoTokenMinter] SUCCESS - Minter created and stored globally (type: ' + typeof mintCallback + ')');
    }

    /**
     * Mints a poToken using the pre-created minter callback.
     * The minter MUST have been created during initialization via createPoTokenMinter().
     * NOTE: mintCallback() may return a Promise, so this function is async.
     * @param identifier - The identifier to bind the token to (as Uint8Array)
     * @returns Promise<Uint8Array> containing the poToken
     */
    async function obtainPoToken(identifier) {
      if (!poTokenMinter) {
        throw new Error('MNT:NotInit - poTokenMinter was not initialized. Call createPoTokenMinter first.');
      }

      // Mint the token with the identifier
      // NOTE: mintCallback() may return a Promise, so we await it
      var result;
      try {
        var mintResult = poTokenMinter(identifier);
        // Handle both sync and async mintCallback
        if (mintResult && typeof mintResult.then === 'function') {
          console.log('[obtainPoToken] mintCallback returned a Promise, awaiting...');
          result = await mintResult;
        } else {
          result = mintResult;
        }
      } catch (e) {
        throw new Error('MNT:Failed - mintCallback() threw: ' + e.message);
      }

      if (!result) {
        throw new Error('YNJ:Undefined - mint result is undefined');
      }

      if (!(result instanceof Uint8Array)) {
        throw new Error('ODM:Invalid - result is not Uint8Array, got: ' + Object.prototype.toString.call(result));
      }

      // Validate token size (expected 110-128 bytes per BgUtils documentation)
      if (result.length < 100 || result.length > 140) {
        console.warn('[obtainPoToken] Token size ' + result.length + ' bytes may be outside expected range (110-128)');
      }

      return result;
    }
</script></head><body></body></html>
"""
