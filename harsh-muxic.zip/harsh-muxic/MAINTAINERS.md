# Maintainers

This document lists the maintainers responsible for Harsh muxic.

| Maintainer | GitHub | Responsibilities |
|---|---|---|
| Kushagra Singh | [@kushagrasinghx](https://github.com/kushagrasinghx) | Project creator, core architecture, release management, and PR reviews |

## Responsibilities

Maintainers oversee project direction, repository maintenance, review and merging of contributions, and release management.

## Contributors

This list is automatically generated from GitHub repository contributor data.

<!-- BEGIN CONTRIBUTORS -->
- [@kushagrasinghx](https://github.com/kushagrasinghx)
- [@Galaxyyss](https://github.com/Galaxyyss)
- [@NeoTurcios](https://github.com/NeoTurcios)
- [@hongducdev](https://github.com/hongducdev)
- [@kmmiio99o](https://github.com/kmmiio99o)
- [@byburak3525](https://github.com/byburak3525)
- [@penetratorcwl](https://github.com/penetratorcwl)
- [@nitinbhat972](https://github.com/nitinbhat972)
- [@AbhiTheModder](https://github.com/AbhiTheModder)
- [@AngelCas04](https://github.com/AngelCas04)
- [@MaverickRox](https://github.com/MaverickRox)
- [@aryasarukkai](https://github.com/aryasarukkai)
- [@Eful97](https://github.com/Eful97)
- [@chaudharyjatin115](https://github.com/chaudharyjatin115)
- [@bazilbycom](https://github.com/bazilbycom)
- [@BernoldM](https://github.com/BernoldM)
- [@Elitenotavailable](https://github.com/Elitenotavailable)
- [@InfantAjith96](https://github.com/InfantAjith96)
- [@SHUBH-snippet](https://github.com/SHUBH-snippet)
- [@yxyydev](https://github.com/yxyydev)
<!-- END CONTRIBUTORS -->
